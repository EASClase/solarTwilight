/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.login;

/**
 *
 * @author Chikiritaviri
 */
public class Login {

    public static void main(String[] args) {
        FormLogin formLogin = new FormLogin();
        formLogin.setVisible(true);
    }
}
