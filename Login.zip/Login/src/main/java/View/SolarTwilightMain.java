/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package View;

/**
 *
 * @author Chikiritaviri
 */
public class SolarTwilightMain {

    public static void main(String[] args) {
        FormLogin formLogin = new FormLogin();
        formLogin.setVisible(true);
    }
}
