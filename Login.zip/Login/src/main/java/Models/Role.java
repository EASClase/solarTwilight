package Models;

public enum Role {
	ENCARGADO,
	AUXILIAR,
	REPARTIDOR
}
