/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

import java.util.Date;
import java.util.List;

/**
 *
 * @author debian
 */
public class Ticket {
    
    private List pedido;
    private String forma_pago;
    private Date fecha;
    private long id;
    private String tipoPedido;
    
    public Ticket(List pedido, String forma_pago, Date fecha, long id, String tipoPedido){
        this.pedido = pedido;
        this.forma_pago = forma_pago;
        this.fecha = fecha;
        this.id = id;
        this.tipoPedido = tipoPedido;
    }

    public List getPedido() {
        return pedido;
    }

    public String getForma_pago() {
        return forma_pago;
    }

    public Date getFecha() {
        return fecha;
    }

    public long getId() {
        return id;
    }

    public String getTipoPedido() {
        return tipoPedido;
    }

    public void setPedido(List pedido) {
        this.pedido = pedido;
    }

    public void setForma_pago(String forma_pago) {
        this.forma_pago = forma_pago;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setTipoPedido(String tipoPedido) {
        this.tipoPedido = tipoPedido;
    }
    
    
    
    public void imprimir(){
        
        
        
    }
    
}
